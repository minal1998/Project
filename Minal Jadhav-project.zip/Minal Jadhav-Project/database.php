<?php
$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo "Not connected to server";
}
if(!mysqli_select_db($con,'contact_db'))
{
	echo "Database Not selected";
}
$Name = $_POST['Name'];
$Email = $_POST['Email'];
$Message = $_POST['Message'];
$sql = "INSERT INTO contact_table (Name,Email,Message) VALUES ('$Name','$Email','$Message')";
if(!mysqli_query($con,$sql))
{
	echo "Invalid Information..";
}
else
{
	header("Location: index.html");
}
?>